#!/bin/sh
source ./config

megareg --help

#
# Use http://www.hidemyass.com/anonymous-email
#

megareg --register --email mt123456@hmamail.com --name MegaTools --password qweqweqwe

#
# Continue from there on, as queried on the command line
#
