#!/bin/sh
source ./config

killall megafs

