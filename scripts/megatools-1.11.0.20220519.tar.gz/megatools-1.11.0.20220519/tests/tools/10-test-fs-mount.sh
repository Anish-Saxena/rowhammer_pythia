#!/bin/sh
source ./config

mkdir -p Mount
megafs $ROPTS Mount
