#!/bin/sh
source ./config

megadf --help

megadf $OPTS
megadf $OPTS -h
